const movies = [
  {
    title: "Midnight Run",
    genre: "Action • 2026",
    description: "A fictional action movie demo for the Trizzy Movies website.",
    poster: "https://placehold.co/600x900/161616/ffffff?text=Midnight+Run",
    trailer: "https://www.youtube.com/results?search_query=movie+trailer"
  },
  {
    title: "The Last Mission",
    genre: "Action • 2026",
    description: "A fictional mission thriller demo. Replace this information with content you are authorized to publish.",
    poster: "https://placehold.co/600x900/1b1b1b/ffffff?text=The+Last+Mission",
    trailer: "https://www.youtube.com/results?search_query=movie+trailer"
  },
  {
    title: "City Lights",
    genre: "Drama • 2025",
    description: "A fictional drama movie demo for your movie discovery site.",
    poster: "https://placehold.co/600x900/202020/ffffff?text=City+Lights",
    trailer: "https://www.youtube.com/results?search_query=movie+trailer"
  },
  {
    title: "Beyond Earth",
    genre: "Sci-Fi • 2026",
    description: "A fictional science-fiction title used as sample content.",
    poster: "https://placehold.co/600x900/181818/ffffff?text=Beyond+Earth",
    trailer: "https://www.youtube.com/results?search_query=movie+trailer"
  },
  {
    title: "Shadow Code",
    genre: "Thriller • 2025",
    description: "A fictional thriller demo for the Trizzy Movies catalog.",
    poster: "https://placehold.co/600x900/242424/ffffff?text=Shadow+Code",
    trailer: "https://www.youtube.com/results?search_query=movie+trailer"
  },
  {
    title: "Golden Road",
    genre: "Adventure • 2026",
    description: "A fictional adventure title. Add your own licensed movie details here.",
    poster: "https://placehold.co/600x900/191919/ffffff?text=Golden+Road",
    trailer: "https://www.youtube.com/results?search_query=movie+trailer"
  },
  {
    title: "After Dark",
    genre: "Horror • 2025",
    description: "A fictional horror movie demo.",
    poster: "https://placehold.co/600x900/151515/ffffff?text=After+Dark",
    trailer: "https://www.youtube.com/results?search_query=movie+trailer"
  },
  {
    title: "Final Horizon",
    genre: "Sci-Fi • 2026",
    description: "A fictional sci-fi movie demo.",
    poster: "https://placehold.co/600x900/202020/ffffff?text=Final+Horizon",
    trailer: "https://www.youtube.com/results?search_query=movie+trailer"
  }
];

const grid = document.getElementById("movieGrid");
const searchInput = document.getElementById("searchInput");
const noResults = document.getElementById("noResults");
const modal = document.getElementById("movieModal");
const closeModal = document.getElementById("closeModal");
const modalPoster = document.getElementById("modalPoster");
const modalTitle = document.getElementById("modalTitle");
const modalGenre = document.getElementById("modalGenre");
const modalDescription = document.getElementById("modalDescription");
const trailerBtn = document.getElementById("trailerBtn");

function renderMovies(list) {
  grid.innerHTML = "";

  list.forEach((movie, index) => {
    const card = document.createElement("article");
    card.className = "movie-card";
    card.innerHTML = `
      <img class="movie-poster" src="${movie.poster}" alt="${movie.title} poster" loading="lazy">
      <div class="movie-info">
        <h3>${movie.title}</h3>
        <p class="movie-meta">${movie.genre}</p>
        <button class="card-btn" data-index="${index}">View Details</button>
      </div>
    `;

    card.querySelector(".card-btn").addEventListener("click", () => openMovie(movie));
    grid.appendChild(card);
  });

  noResults.hidden = list.length !== 0;
}

function openMovie(movie) {
  modalPoster.src = movie.poster;
  modalPoster.alt = `${movie.title} poster`;
  modalTitle.textContent = movie.title;
  modalGenre.textContent = movie.genre;
  modalDescription.textContent = movie.description;
  trailerBtn.href = movie.trailer;
  modal.classList.add("show");
  modal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
}

function closeMovie() {
  modal.classList.remove("show");
  modal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}

searchInput.addEventListener("input", (event) => {
  const term = event.target.value.toLowerCase().trim();
  const filtered = movies.filter(movie =>
    `${movie.title} ${movie.genre}`.toLowerCase().includes(term)
  );
  renderMovies(filtered);
});

closeModal.addEventListener("click", closeMovie);

modal.addEventListener("click", (event) => {
  if (event.target === modal) closeMovie();
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeMovie();
});

document.getElementById("year").textContent = new Date().getFullYear();

renderMovies(movies);
